def displayr(lastn,score):
  l=len(lastn)
  print("Number of array elements",l)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y],score[y])
  print("Arrays in reverse order")
  for y in  range(l-1,-1,-1):
    print(lastn[y],score[y])


def hilow(lastn,score):
  l = len(lastn)
  hiscore = -1.0
  lowscore = 999
  for y in range (0,l,1):
    if float(score[y])> float(hiscore):
      hiindex = y 
      hiscore = score[y]
    if float(score[y]) < float(lowscore):
      lowindex = y
      lowscore = score[y]
  
  print("Highest score",lastn[hiindex], score[hiindex])
  print("Lowest score",lastn[lowindex], score[lowindex])

    
f = open("lnames.txt","r")

c = 0

lastname = f.readline()
lastn = []
score = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()

f.close()

#displaynames(lastn,salary)

displayr(lastn,score)

hilow(lastn,score)