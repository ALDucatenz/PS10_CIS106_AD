def displayr(lastn,avg):
  l=len(lastn)
  print("Number of array elements",l)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y],avg[y])
  print("Arrays in reverse order")
  for y in  range(l-1,-1,-1):
    print(lastn[y],avg[y])


def hilow(lastn,avg):
  l = len(lastn)
  hiavg = -1.0
  lowavg = 999
  for y in range (0,l,1):
    if float(avg[y])> float(hiavg):
      hiindex = y 
      hiavg = avg[y]
    if float(avg[y]) < float(lowavg):
      lowindex = y
      lowavg = avg[y]
  
  print("Highest batting avg:",lastn[hiindex], avg[hiindex])
  print("Lowest avg:",lastn[lowindex], avg[lowindex])

def seqsearch(lastn,sname):
  l = len(lastn)
  sindex = -1
  for y in range(0,l,1):
    if lastn[y] == sname:
      sindex = y
  
  return sindex


    
f = open("lnames.txt","r")

c = 0

lastname = f.readline()
lastn = []
avg = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  avg.append(s)
  lastname = f.readline()

f.close()

#displaynames(lastn,salary)

displayr(lastn,avg)
hilow(lastn,avg)

response = input("Do you want to search for a name? (Yes or No): ")

while response == "Yes":
  sname = input("Enter last name: ")

  i = seqsearch(lastn,sname)

  print("Batting average of", lastn[i],"is",avg[i])

  response = input("Do you want to search for a name? (Yes or No): ")


