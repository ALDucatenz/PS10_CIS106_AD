#def displaynames(lastn,salary):
  #for i in lastn, salary:
    #print(i)
  #for y in salary:
    #print(y)
def displayr(lastn):
  l=len(lastn)
  print("Number of array elements",l)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y])
  print("Arrays in reverse order")
  for y in  range(l-1,-1,-1):
    print(lastn[y])

    





f = open("lnames.txt","r")

c = 0

lastname = f.readline()
lastn = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))

  lastname = f.readline()

f.close()

#displaynames(lastn,salary)

displayr(lastn)