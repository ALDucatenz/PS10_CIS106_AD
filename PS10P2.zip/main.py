
def displayr(lastn,score):
  l=len(lastn)
  print("Number of array elements",l)
  print("Arrays in order")
  for y in range (0,l,1):
    print(lastn[y],score[y])
  print("Arrays in reverse order")
  for y in  range(l-1,-1,-1):
    print(lastn[y],score[y])

    





f = open("lnames.txt","r")

c = 0

lastname = f.readline()
lastn = []
score = []
while lastname != "":
  c = c + 1
  lastn.append(str(lastname).rstrip("\n"))
  s = float(f.readline())
  score.append(s)
  lastname = f.readline()

f.close()

#displaynames(lastn,salary)

displayr(lastn,score)